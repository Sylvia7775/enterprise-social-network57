export type UserRole="member"|"creator"|"business"|"moderator"|"admin";
export type MediaType="image"|"video"|"pdf"|"audio"|"document";
export type Visibility="public"|"friends"|"followers"|"private";
