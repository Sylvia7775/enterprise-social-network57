# admin-service
Admin dashboard for users, verification, marketplace, groups, channels and settings.
