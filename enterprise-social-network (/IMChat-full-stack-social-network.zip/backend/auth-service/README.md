# auth-service
JWT/session auth, registration, login, verification and RBAC.
