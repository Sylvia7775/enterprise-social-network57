import type { ReactNode } from "react";
import "./globals.css";
export const metadata={title:"IMChat",description:"Social network, creators, groups, channels and marketplace."};
export default function RootLayout({children}:{children:ReactNode}) {
 return <html lang="en"><body>{children}</body></html>;
}
