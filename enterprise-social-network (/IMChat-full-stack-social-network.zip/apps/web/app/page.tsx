import Link from "next/link";
export default function Home(){return <main className="min-h-screen bg-white">
<header className="border-b"><div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
<b className="text-2xl">IMChat</b><nav className="flex gap-4 text-sm"><Link href="/reels">Reels</Link><Link href="/messages">Chat</Link><Link href="/groups">Groups</Link><Link href="/channels">Channels</Link><Link href="/marketplace">Marketplace</Link></nav>
</div></header><section className="mx-auto max-w-6xl px-5 py-20"><h1 className="text-5xl font-bold">Connect. Create. Share. Shop.</h1><p className="mt-5 text-lg text-zinc-600">Profiles, messaging, Reels, groups, channels and Marketplace in one IMChat platform.</p></section>
<footer className="border-t py-8 text-center text-sm text-zinc-500">Privacy · Careers · Feedback · FAQ<br/>Copyright 2026 © IMChat,Inc</footer></main>}
