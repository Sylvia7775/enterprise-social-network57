# Roadmap
Auth → profiles → feed → messaging/calls → Reels/AI creator → groups/moderation → channels/live → Marketplace/shops → payments/orders → admin → production scaling.
