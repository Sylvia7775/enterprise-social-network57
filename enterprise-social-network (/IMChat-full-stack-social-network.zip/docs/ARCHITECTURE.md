# IMChat Architecture
Next.js web client + modular backend services + PostgreSQL transactional storage + Redis/WebSockets for real-time features + Cloudinary/CDN for media.

Security: authorize every mutation, keep secrets server-side, never trust client prices/inventory/payment state, and verify payment webhooks server-side.
